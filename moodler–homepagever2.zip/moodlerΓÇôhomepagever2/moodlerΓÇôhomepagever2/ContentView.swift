//
//  ContentView.swift
//  moodler–homepagever2
//
//  Created by Ceri Tahimic on 18/10/2025.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        HomeView()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
