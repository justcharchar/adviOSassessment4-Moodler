//
//  moodler_homepagever2App.swift
//  moodler–homepagever2
//
//  Created by Ceri Tahimic on 18/10/2025.
//

import SwiftUI

@main
struct moodler_homepagever2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
