//
//  MoodHistoryView.swift
//  moodler–homepagever2
//
//  Created by Ceri Tahimic on 18/10/2025.
//

import SwiftUI

struct MoodHistoryView: View {
    var body: some View {
        Text("Mood History View")
            .navigationTitle("Mood History")
    }
}
