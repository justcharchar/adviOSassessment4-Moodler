//
//  JournalEntryView–temp.swift
//  moodler–homepagever2
//
//  Created by Ceri Tahimic on 18/10/2025.
//

import SwiftUI

struct JournalEntryView: View {
    var body: some View {
        NavigationView {
            Text("Journal Entry View")
                .navigationTitle("New Journal Entry")
                .navigationBarItems(leading: Button("Cancel") { })
        }
    }
}

